package org.junit.tests.validation.anotherpackage;

import org.junit.Test;

class Super {
	@Test public void a() {}
}
