package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
import junit.framework.TestCase;

public class OneTestCase extends TestCase {
	public void noTestCase() {
	}
	public void testCase() {
	}
	public void testCase(int arg) {
	}
}